classdef second
    methods(Static)
        function res = Molecule(par,matrix_one,matrix_two,res,record)
            %Start Iterating
            for o = 1:par.loop
                %Initialize variables fym1, fym2, fym3
                fym1 = zeros(50, par.moc_size*2)
                fym2 = zeros(1, par.moc_size*2)
                fym3 = zeros(1, par.moc_size*2)
                %Select "moc_num * moc_size" elements.
                moc = second.method1(par.moc_num,par.moc_size,matrix_one,matrix_two);
                %For each moc matrix, start 20 iterations
                for a = 1:par.iter
                    if (rand < par.cross_rate) 
                        if (rand < par.cross_rate+0.2)
                           % Monomolecular Collision Reaction
                           fym1 = second.method_two(a,par.moc_num,par.moc_size,moc,matrix_one,fym1,record); 
                        else
                           % Monomolecular Decomposition Reaction
                           fym1 = second.method_three(a,par.moc_num,par.moc_size,moc,matrix_one,fym1,record);
                        end
                    else
                        if (rand < par.cross_rate+0.2)
                            % Polymolecular Collision Reaction
                           fym1 = second.method_four(a,par.moc_num,par.moc_size,moc,fym1);
                        else
                           % Polymolecular Combination Reaction
                           fym1 = second.method_five(a,par.moc_num,par.moc_size,moc,matrix_one,fym1,record);
                        end
                    end
                    % Keep the row with the largest sum in 20 iterations
                    fym2 = second.method_six(fym1,fym2,fym3,a);
                end
                % Write the results of fym2 to res
                res(o, :) = fym2;
            end
        end
    end
    methods(Static)
        function moc = method1(moc_num,moc_size,matrix_one,matrix_two)
            for i = 1:moc_num
                for j = 1:moc_size
                    moc(i, 1:4) = matrix_one(randi(numel(matrix_one), 1, 4));
                    moc(i, 5:10) = matrix_two(randi(numel(matrix_two), 1, 6)); % Selection of proteins as substitutes based on homogeneity rates
                end
            end
        end
        
        function fym1 = method_two(a,moc_num,moc_size,moc,matrix_one,fym1,record)
            i = randperm(moc_num, 1);
            X1 = moc(i, :);
            N = X1;
            PE1 = max(X1);
            for i = 1:(moc_size - 1)
                b = randperm(moc_size, 1);
                posterior_prob = zeros(1,3);
                for o = 1:5
                    h = randi(numel(matrix_one), 1);
                    posterior_prob_1 = Naive_Bayes_Model.bayer(record(:,4:6),record(:,8),record(h,4:6));
                    if posterior_prob_1 > posterior_prob
                        posterior_prob = posterior_prob_1;
                        k = h;
                    end
                end
                X1(b) = matrix_one(k);
            end
            X2 = X1;
            PE2 = max(X2);
            
            if PE1 >= PE2
                fym1(a, 1:moc_size) = N;
            else
                fym1(a, 1:moc_size) = X2;
            end
        end
        
        function fym1 = method_three(a,moc_num,moc_size,moc,matrix_one,fym1,record)
            i = randperm(moc_num, 1);
            X1 = moc(i, :)
            
            PE1 = max(X1);
            for i = 1:moc_size
                posterior_prob_three = zeros(1,3);
                if rem(i, 2) == 0
                    m = randperm(moc_size, 1);
                    n = randperm(moc_size, 1);
                    X2(i) = X1(1, m)
                    X3(i) = X1(1, n)
                else
                    for o = 1:5
                        h = randi(numel(matrix_one), 1);
                        posterior_prob_1 = Naive_Bayes_Model.bayer(record(:,4:6),record(:,8),record(h,4:6));
                        if posterior_prob_1 > posterior_prob_three
                            posterior_prob_three = posterior_prob_1;
                            k = h;
                        end
                    end
                    X2(i) = matrix_one(k);
                    X3(i) = matrix_one(h);
                end
            end
            
            PE2 = max(X2);
            PE3 = max(X3);
            
            
            if PE1 >= PE2 + PE3
                fym1(a, 1:moc_size) = X1;
            else
                fym1(a, :) = [X2, X3];
            end
        end
        
        function fym1 = method_four(a,moc_num,moc_size,moc,fym1)
            i = randperm(moc_num, 1);
            j = randperm(moc_num, 1);
            X1 = moc(i, :)
            X2 = moc(j, :)
            PE1 = max(X1);
            PE2 = max(X2);
            for i = 1:moc_size
                if rem(i, 2) == 0
                    X3(i) = X1(1, randperm(moc_size, 1))
                else
                    X3(i) = X2(1, randperm(moc_size, 1))
                end
            end
            
            PE3 = max(X3);
            
            
            if PE1 + PE2 >= PE3
                fym1(a, :) = [X1, X2];
            else
                fym1(a, 1:moc_size) = X3;
            end
        end
        
        function fym1 = method_five(a,moc_num,moc_size,moc,matrix_one,fym1,record)
            i = randperm(moc_num, 1);
            j = randperm(moc_num, 1);
            X1 = moc(i, :)
            X2 = moc(j, :)
            M = X1
            N = X2
            PE1 = max(X1);
            PE2 = max(X2);
            for i = 1:(moc_size - 1)
                b = randperm(moc_size, 1);
                posterior_prob_five = zeros(1,3);
                for o = 1:5
                    h = randi(numel(matrix_one), 1);
                    posterior_prob_1 = Naive_Bayes_Model.bayer(record(:,4:6),record(:,8),record(h,4:6));
                    if posterior_prob_1 > posterior_prob_five
                        posterior_prob_five = posterior_prob_1;
                        k = h;
                    end
                end
                X1(b) = matrix_one(k);
                c = randperm(moc_size, 1);
                for o = 1:5
                    h = randi(numel(matrix_one), 1);
                    posterior_prob_1 = Naive_Bayes_Model.bayer(record(:,4:6),record(:,8),record(h,4:6));
                    if posterior_prob_1 > posterior_prob_five
                        posterior_prob_five = posterior_prob_1;
                        k = h;
                    end
                end
                X2(c) = matrix_one(k);
            end
            X3 = X1;
            PE3 = max(X2);
            
            X4 = X2;
            PE4 = max(X4);
            
            %fym1(a,:)=[X1,X2,X3,X4];
            if (PE1 + PE2) >= (PE4 + PE3)
                fym1(a, :) = [M, N];
            else
                fym1(a, :) = [X3, X4];
            end
        end
        
        function fym2 = method_six(fym1,fym2,fym3,a)
            fym3(1, :) = fym1(a, :)
           
            if a == 1
                fym2(1, :) = fym3
            else
                if sum(fym3) >= sum(fym2)
                    fym2(1, :) = fym3
                end
            end
        end
        
    end
    
end
