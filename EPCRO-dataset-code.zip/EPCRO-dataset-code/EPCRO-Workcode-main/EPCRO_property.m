 classdef EPCRO_property < handle
    properties
        PE;
        KE;
        moc_num = 10;
        moc_size = 10; 
        cross_rate = 0.5;
        buffer = 0.0;
        loop = 4;
        iter = 20;
        totalNo_DIP = 5093;
        essential_proteins_DIP = 1167;
        DIP_TOP25Num = 1274;
        totalNo_GAVIN = 1855;
        essential_proteins_GAVIN = 714;
        GAVIN_TOP25Num = 464;
    end
end
