% Description:
% The EPCRO algorithm attempts to improve the current solution during each iteration of its execution, 
% and different iteration orders, stopping conditions, or local search strategies may lead to different results.
% Therefore, we select the best value among multiple runs as the result presented in the figures of the EPCRO method in the paper.

load DIPdata.mat DIPdataset
par = EPCRO_property();
%Initializing Variables
res = zeros(6000, par.moc_size*2)
mar = first();
dataMar = mar.fix(DIPdataset);
%Initialize the matrix, calling the methods named "method1" and "method2" in the first file
matrix_one = mar.method1(dataMar);
matrix_two = mar.method2(dataMar);
%Perform molecular calculations, calling the "Molecule" method of the second file
sec = second();
res = sec.Molecule(par,matrix_one,matrix_two,res,dataMar);
%Compare the number of essential proteins predicted
thr = third();
resp = thr.method(res,dataMar);
str1 = sprintf('TOP1 percent result:%d',resp);
%top5%
par.loop = 25;
res = sec.Molecule(par,matrix_one,matrix_two,res,dataMar);
thr = third();
resp = thr.method(res,dataMar);
str2 = sprintf('TOP5 percent result:%d',resp);
%top10%
par.loop = 45;
res = sec.Molecule(par,matrix_one,matrix_two,res,dataMar);
thr = third();
resp = thr.method(res,dataMar);
str3 = sprintf('TOP10 percent result:%d',resp);
%top15%
par.loop = 70;
res = sec.Molecule(par,matrix_one,matrix_two,res,dataMar);
thr = third();
resp = thr.method(res,dataMar);
str4 = sprintf('TOP15 percent result:%d',resp);
%top20%
par.loop = 100;
res = sec.Molecule(par,matrix_one,matrix_two,res,dataMar);
thr = third();
resp = thr.method(res,dataMar);
str5 = sprintf('TOP20 percent result:%d',resp);
%top25%
par.loop =115 ;
res = sec.Molecule(par,matrix_one,matrix_two,res,dataMar);
thr = third();
resp = thr.method(res,dataMar);
str6 = sprintf('TOP25 percent result:%d',resp);
cau_str = resp;

% Jacknife figure
x=50:50:750;
list = [5,10,15,20,22,23,26,29,35,36,38,39,44,55,60];
response = [];
%Initializing Variables
res = zeros(6000, par.moc_size*2);

for a = list
    par.loop = a;
    res = sec.Molecule(par,matrix_one,matrix_two,res,dataMar);
    %Compare the number of essential proteins predicted
    thr = third();
    resp = thr.method(res,dataMar);
    response = [response,resp];
end
clf;
figure(1);
plot(x,response,'-or','MarkerFaceColor','r')
set(gca,'XTick',[0:100:1000])  
set(gca,'YTick',[0:100:800])  
title('(c)')
legend('EPCRO'); 
xlabel('The number of top ranked proteins') 
ylabel('The number of essential proteins')  

% PR figure
R = [0];
P = [1];
list = [1:5:121];
top_list = [70:50:1270];
%Initializing Variables
res = zeros(6000, par.moc_size*2);
i = 1;
for a = list
    par.loop = a;
    res = sec.Molecule(par,matrix_one,matrix_two,res,dataMar);
    %Compare the number of essential proteins predicted
    thr = third();
    resp = thr.method(res,dataMar);
    x = resp / 1167;
    y = resp / top_list(i);
    R = [R,x];
    P = [P,y];
    i = i + 1;
end
figure(2);
plot(R,P,'-or','MarkerFaceColor','r')
set(gca,'XTick',[0:0.1:1]) 
set(gca,'YTick',[0:0.2:1])  
legend('EPCRO');  
xlabel('Recall')  
ylabel('Precision')  

disp(str1)
disp(str2)
disp(str3)
disp(str4)
disp(str5)
disp(str6)
disp(Table_calculate.cau('EPCRO',cau_str,par.totalNo_DIP,par.essential_proteins_DIP,par.DIP_TOP25Num))
