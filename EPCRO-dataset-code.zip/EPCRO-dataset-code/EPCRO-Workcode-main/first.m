classdef first
    methods(Static)
        function dataMar = fix(obj)
            for i = 2:8
                dataMar(:,i) = table2array(obj(:,i))
            end
        end
        function data_gavin = handle(obj)
            for i = 2:8
                data_gavin(:,i) = table2array(obj(:,i));
            end
        end
     
        function matrix_one = method1(obj) 
            %This method gets matrix_one
            %If column 8 of the dataset is 1 (i.e., it is the key protein), then put the value of column 7 of this record into matrix_one
            row = size(obj,1)
            for i = 1:row
                if obj(i, 8) == 1
                    matrix_one(i, 1) = obj(i, 7);
                else
                    matrix_two(i, 1) = obj(i, 7);
                end
            end
            matrix_one = unique(matrix_one)
            matrix_two = unique(matrix_two)
        end
        function matrix_two = method2(obj)
            %Get matrix_two
            row = size(obj,1);
            for i = 1:row
                if obj(i, 8) == 1
                    matrix_one(i, 1) = obj(i, 7);
                else
                    matrix_two(i, 1) = obj(i, 7);
                end
            end
            matrix_one = unique(matrix_one)
            matrix_two = unique(matrix_two)
            
        end
    end
end
