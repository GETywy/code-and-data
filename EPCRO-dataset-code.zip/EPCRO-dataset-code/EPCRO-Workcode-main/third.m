classdef third
    methods(Static)
        function resp = method(res,obj)
            % Filtering the final results
            compare = unique(res);
            % Comparison of essential proteins obtained from EPCRO with
            % essential proteins in the original dataset.
            for i = 1:length(compare)
                for j = 1:size(obj,1)
                    if compare(i, 1) == obj(j, 7)
                        compare(i, 2) = obj(j, 8);
                    end
                end
            end
            %Calculate the number of essential proteins predicted by EPCRO.
            resp = sum(compare(:, 2))
        end
    end
    
end
